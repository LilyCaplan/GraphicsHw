#!/bin/sh
make -C /Users/lilycaplan/Documents/workspace/spring2019/cs472/NewHw/CS472.skel/ -f CS472.xcodeproj/qt_makeqmake.mak
